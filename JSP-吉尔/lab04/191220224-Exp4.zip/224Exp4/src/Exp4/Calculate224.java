package Exp4;

public class Calculate224 {
}
