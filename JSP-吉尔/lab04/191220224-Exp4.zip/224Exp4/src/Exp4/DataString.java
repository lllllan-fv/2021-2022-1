package Exp4;

public class DataString {
}
